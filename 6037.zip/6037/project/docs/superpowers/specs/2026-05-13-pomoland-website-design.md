# Pomoland Website Design

Date: 2026-05-13
Source document: `副本function(1).docx`
Delivery target: runnable desktop web demo for a Hong Kong course presentation

## 1. Product Direction

Pomoland is a desktop web presentation and interactive product demo for a focus habit product. The concept combines AI task planning, Pomodoro-style focus sessions, variable rewards, island building, check-ins, reports, and light social interaction.

The site must work well for computer projection in class. It should be understandable without setup, backend services, database, API keys, or network access.

Brand terms stay in English, including `Pomoland`, `Focus Mode`, `Bonus`, and `Launch Demo`. Main interface copy supports three languages:

- Simplified Chinese
- Traditional Chinese
- English

## 2. Confirmed Design Decisions

- Website form: desktop web page for projection, not a mobile app shell.
- Structure: product homepage plus independent interactive demo workspace.
- Visual direction: bright island style, youthful and game-like, but still clear enough for presentation.
- Main demo journey: AI task planning -> Focus Mode -> Bonus reward -> Pomoland island building.
- Feature scope: full showcase version, including the main journey plus check-in calendar, friends interaction, and growth report.
- Timer behavior: both real focus durations and a demo fast-forward mode.
- Technical delivery: static frontend files that can run by opening `index.html`.

## 3. Audience And Presentation Goals

The primary audience is a course instructor and classmates in a Hong Kong classroom. The site should help the presenter explain:

1. The user problem: people struggle to break big goals into daily action and sustain focus.
2. The product loop: planning, focusing, receiving rewards, building a personal island, and returning the next day.
3. The AI value: task decomposition, anti-procrastination nudges, emotional companion copy, and progress summaries.
4. The game value: variable rewards, check-in streaks, island decoration, and lightweight friend interaction.

Success means a viewer can understand the product concept within the first screen, then watch a complete interactive demo in a few minutes.

## 4. Website Structure

### 4.1 Homepage

The homepage explains Pomoland as a product concept and points visitors into the demo.

Sections:

- Hero: brand, concise value proposition, language switcher, `Launch Demo` call to action, and bright island product preview.
- Journey: a horizontal user flow showing AI planning, Focus Mode, Bonus, check-in, island building, and return loop.
- Features: cards for AI task planning, Pomodoro focus, virtual island, variable rewards, check-in streaks, friends, and reports.
- AI Layer: explains goal decomposition, anti-procrastination intervention, emotional companion copy, and growth summaries.
- Demo CTA: a second entry point into the interactive workspace.

The hero should communicate the product quickly. Example English message:

`Turn focus into your own island.`

Chinese versions should keep the same meaning rather than being literal translations.

### 4.2 Demo Workspace

The demo workspace should feel like a real desktop product interface. It uses a left navigation rail and a main content area.

Navigation items:

- Today / AI Plan
- Focus Mode
- Pomoland Island
- Check-in
- Friends
- Report

The workspace should include a clear scripted path so the presenter can complete the core journey without improvising.

## 5. Core Demo Flow

### 5.1 AI Task Planning

The user sees a goal input with a preset goal, for example:

- Simplified Chinese: `三个月准备雅思考试`
- Traditional Chinese: `三個月準備雅思考試`
- English: `Prepare for IELTS in 3 months`

After clicking an AI planning button, the site shows a short loading state and generates a structured list of smaller tasks. This is simulated, not a real API call.

Example generated tasks:

- Vocabulary sprint, 25 minutes
- Listening practice, 30 minutes
- Reading set, 45 minutes
- Writing outline, 25 minutes

The user selects one task to send into Focus Mode.

### 5.2 Focus Mode

Focus Mode shows:

- Selected task title
- Circular or prominent timer
- Duration options: Demo 20s, 25m, 30m, 45m
- Start, pause, and reset controls
- A small Pomoland island or tomato character animation area

For classroom use, `Demo 20s` should be the default or clearly available. Real durations remain visible to show the product can support normal Pomodoro use.

### 5.3 Bonus Reward

When the demo timer completes, a Bonus modal appears. It should feel rewarding and quick to understand.

Possible rewards:

- Coins
- Seeds
- Water drops
- Game chances
- Rare decoration item

The modal includes a `Claim Bonus` button. Claiming updates the user's resources and advances the journey to the island screen.

### 5.4 Pomoland Island Building

The island screen shows a bright island scene and resource counters. The user can spend rewards through simple actions:

- Plant
- Water
- Feed
- Decorate

The island should visibly change after actions, such as adding a sprout, growing a plant, showing a water sparkle, or unlocking a small decoration. These can be CSS/HTML visuals rather than image-heavy assets.

### 5.5 Check-in Calendar

After a completed focus session, today's date is highlighted. The screen shows:

- Current streak
- Milestone rewards at 7, 30, and 100 days
- Streak protection card concept

This page proves the long-term habit loop.

### 5.6 Friends

The Friends screen displays several friend island cards. Each card includes a name, recent focus status, island state, and possible actions:

- Help water
- Visit
- Steal fruit

Actions consume one game chance where relevant and update small status messages. The interaction should be light and playful, not punitive.

### 5.7 Report

The Report screen shows:

- 7-day focus trend
- Task completion rate
- Current streak
- Resource earned summary
- AI weekly summary paragraph

The chart can be implemented with simple CSS bars or inline SVG. No external chart library is required unless already available.

## 6. Language System

All visible text in the homepage and demo workspace should be driven by a small translation dictionary in JavaScript.

Rules:

- The language switcher appears in the top right of the homepage and remains available in the demo workspace.
- The selected language updates all major UI copy immediately.
- Brand terms remain English across languages.
- Simplified and Traditional Chinese should be separate entries, not automated conversion at runtime.
- Demo data, reward names, report summaries, and button labels should all be translated.

The default language can be Simplified Chinese unless the user later requests a different default for the class.

## 7. Visual Design

The selected visual direction is bright island style.

Key qualities:

- Fresh, sunny, and memorable
- Uses turquoise, tomato red, seed yellow, leaf green, and warm white
- Avoids a dark, corporate, or heavy dashboard mood
- Keeps cards and panels tidy for projection readability
- Uses 8px radius or less for most UI cards and controls, unless a circular timer or island object requires roundness

The page should not become a one-color green or blue interface. The island concept should be visible in the first viewport through actual visual elements, not just text.

## 8. Interaction And State

State can be held in browser memory during the session:

- Selected language
- Generated tasks
- Selected task
- Timer mode and remaining time
- Reward resources
- Island progress
- Check-in status
- Friend action messages

No account system, persistent storage, backend, or authentication is required for this version.

The demo should guide the presenter naturally:

1. Click `Launch Demo`.
2. Generate AI tasks.
3. Select one task.
4. Start `Demo 20s` Focus Mode.
5. Claim Bonus.
6. Build the island.
7. Show check-in, friends, and report as supporting pages.

## 9. Technical Plan

Use a static frontend:

- `index.html`: structure for homepage and demo workspace.
- `styles.css`: desktop layout, bright island visual system, responsive safety.
- `app.js`: translations, navigation, demo state, timer, rewards, island actions, friend actions, report text.

No package installation should be required. The site should run by opening the HTML file directly in a browser. If a later decision requires module imports or advanced browser APIs, use a small local dev server, but that is not part of the current design.

## 10. Testing And Verification

Before delivery, verify:

- `index.html` opens directly in a browser.
- Homepage is readable on desktop projection sizes.
- Language switching works for Simplified Chinese, Traditional Chinese, and English.
- `Launch Demo` enters the workspace.
- AI task planning shows loading and generated task cards.
- A task can be selected and used in Focus Mode.
- Demo timer completes without waiting for real Pomodoro duration.
- Bonus modal appears and reward claiming updates resources.
- Island actions visibly update the island or resource state.
- Check-in highlights today after completion.
- Friend actions update messages and game chances.
- Report page displays charts and AI summary.
- Text does not overlap or overflow in common desktop widths.

## 11. Out Of Scope

The following are intentionally excluded from this course-demo version:

- Real user accounts
- Database persistence
- Real LLM API calls
- Push notifications
- Payment, ads, or real streak protection purchase logic
- Backend friend graph
- Real-time multiplayer or team Boss battle
- Mobile app packaging

These can be discussed later if the project moves beyond a course presentation.

## 12. Open Assumptions

- The classroom device can open local HTML files in a modern browser.
- The presentation is mainly on a desktop or laptop screen.
- The default sample goal can be IELTS preparation, because it is understandable in Hong Kong and fits the document's exam-preparation use case.
- The site should prioritize presentation clarity over production architecture.
