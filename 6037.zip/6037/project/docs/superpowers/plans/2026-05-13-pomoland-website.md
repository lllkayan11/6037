# Pomoland Website Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a runnable static desktop website for Pomoland with a product homepage, multilingual copy, and an interactive course-demo workspace.

**Architecture:** Use plain HTML, CSS, and JavaScript so the demo can run by opening `index.html`. Keep reusable product behavior in testable JavaScript functions and connect DOM interactions through a small controller in `app.js`.

**Tech Stack:** Static HTML, CSS, vanilla JavaScript, Node.js built-in test runner.

---

### Task 1: Core Behavior Tests

**Files:**
- Create: `tests/app-core.test.js`
- Later create: `app.js`

- [ ] **Step 1: Write the failing test**

Create tests covering the behavior that powers the demo: translations, AI task generation, reward claiming, island actions, check-in state, friend interactions, and report summary.

```javascript
const test = require('node:test');
const assert = require('node:assert/strict');
const core = require('../app.js');

test('language packs include Simplified Chinese, Traditional Chinese, and English hero copy', () => {
  const languages = core.getSupportedLanguages();
  assert.deepEqual(languages, ['zh-CN', 'zh-HK', 'en']);
  assert.equal(core.t('zh-CN', 'heroTitle'), '把专注变成自己的番茄岛');
  assert.equal(core.t('zh-HK', 'heroTitle'), '把專注變成自己的番茄島');
  assert.equal(core.t('en', 'heroTitle'), 'Turn focus into your own island');
});

test('AI planning generates localized focus tasks from a goal', () => {
  const tasks = core.generateTasks('Prepare for IELTS in 3 months', 'en');
  assert.equal(tasks.length, 4);
  assert.equal(tasks[0].duration, 25);
  assert.match(tasks[0].title, /Vocabulary/);
  assert.ok(tasks.every((task) => task.goal === 'Prepare for IELTS in 3 months'));
});

test('selecting a task moves it into the focus state', () => {
  const state = core.createInitialState();
  const tasks = core.generateTasks('三个月准备雅思考试', 'zh-CN');
  const next = core.selectTask(state, tasks[1]);
  assert.equal(next.selectedTask.id, tasks[1].id);
  assert.equal(next.currentView, 'focus');
});

test('claiming a reward updates resources and marks the focus session complete', () => {
  const state = core.createInitialState();
  const next = core.claimReward(state, {
    coins: 40,
    seeds: 1,
    water: 2,
    chances: 1,
    decoration: 'Solar dock'
  });
  assert.equal(next.resources.coins, 160);
  assert.equal(next.resources.seeds, 3);
  assert.equal(next.resources.water, 5);
  assert.equal(next.resources.chances, 2);
  assert.equal(next.focusCompleted, true);
  assert.equal(next.decorations.includes('Solar dock'), true);
});

test('island actions spend resources and advance island progress', () => {
  const state = core.createInitialState();
  const planted = core.applyIslandAction(state, 'plant');
  assert.equal(planted.resources.seeds, 1);
  assert.equal(planted.islandLevel, 2);
  assert.match(planted.lastMessage.en, /planted/i);

  const watered = core.applyIslandAction(planted, 'water');
  assert.equal(watered.resources.water, 2);
  assert.equal(watered.islandHydration, 1);
});

test('check-in highlights today and increases streak only once', () => {
  const state = core.createInitialState();
  const first = core.recordCheckIn(state, '2026-05-13');
  const second = core.recordCheckIn(first, '2026-05-13');
  assert.equal(first.streak, 6);
  assert.equal(second.streak, 6);
  assert.deepEqual(second.checkIns, ['2026-05-13']);
});

test('friend actions consume chances when needed and update status', () => {
  const state = core.createInitialState();
  const helped = core.performFriendAction(state, 'mia', 'help');
  assert.equal(helped.resources.chances, 0);
  assert.match(helped.friendMessages.mia.en, /watered/i);

  const blocked = core.performFriendAction(helped, 'leo', 'steal');
  assert.equal(blocked.resources.chances, 0);
  assert.match(blocked.friendMessages.leo.en, /No game chances/);
});

test('report data summarizes focus progress for the selected language', () => {
  const state = core.recordCheckIn(core.createInitialState(), '2026-05-13');
  const report = core.buildReport(state, 'en');
  assert.equal(report.days.length, 7);
  assert.equal(report.streak, 6);
  assert.match(report.summary, /Pomoland/);
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `node --test tests/app-core.test.js`

Expected: FAIL because `app.js` does not exist yet.

### Task 2: Static Site Implementation

**Files:**
- Create: `index.html`
- Create: `styles.css`
- Create: `app.js`

- [ ] **Step 1: Implement `app.js` core functions and DOM controller**

Implement the functions required by `tests/app-core.test.js`, expose them through `module.exports` for Node tests, and expose browser behavior through `window.PomolandCore`.

- [ ] **Step 2: Implement `index.html`**

Create the homepage and demo workspace structure with language switcher, hero, journey, features, AI layer, demo navigation, modal, and workspace screens.

- [ ] **Step 3: Implement `styles.css`**

Create the bright island visual system, desktop projection layout, island illustration, cards, charts, modal, responsive safety, and focus states.

- [ ] **Step 4: Run tests**

Run: `node --test tests/app-core.test.js`

Expected: all tests pass.

### Task 3: Verification

**Files:**
- Read/check: `index.html`
- Read/check: `styles.css`
- Read/check: `app.js`

- [ ] **Step 1: Static file check**

Run: `node --check app.js`

Expected: exit code 0.

- [ ] **Step 2: Browser availability check**

Open `index.html` in the in-app browser or use a local static server if direct file browsing is unavailable.

Expected: homepage renders, `Launch Demo` enters the workspace, language switching works, demo timer can complete in fast mode, and Bonus can be claimed.

- [ ] **Step 3: Requirement checklist**

Review the design spec and confirm coverage for homepage, demo workspace, language switching, AI planning, Focus Mode, reward modal, island, check-in, friends, and report.
